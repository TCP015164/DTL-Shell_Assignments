#!/bin/bash

IFS=''

for F in data.txt; do
    while read -r name; do
                read -r GET_HTTP
                read -r User_Agent
                read -r Pragma
                read -r Cache_control
                read -r Accept
                read -r Accept_Encoding
                read -r Accept_Charset
                read -r Accept_Language
                read -r Host
                read -r Cookie
                read -r Connection
            echo "${GET_HTTP#*=}, ${User_Agent#*=}, ${Pragma#*=}, ${Cache_control#*=}, ${Accept#*=}, ${Accept_Encoding#*=}, ${Accept_Charset#*=}, ${Adone#*=}" >>  file.csv
    done < "$F"
done
